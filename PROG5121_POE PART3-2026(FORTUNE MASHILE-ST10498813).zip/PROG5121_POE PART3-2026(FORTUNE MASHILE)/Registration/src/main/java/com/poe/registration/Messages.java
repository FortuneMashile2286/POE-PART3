/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.poe.registration;

/**
 *
 * @author fortune
 */
import javax.swing.JOptionPane;
import java.util.ArrayList;
import java.util.Random;

public class Messages {

// Arrays required by the assignment
public ArrayList<String> sentMessages = new ArrayList<>();
public ArrayList<String> disregardedMessages = new ArrayList<>();
public ArrayList<String> storedMessages = new ArrayList<>();
public ArrayList<String> storedRecipients = new ArrayList<>();
public ArrayList<String> messageHashes = new ArrayList<>();
public ArrayList<String> messageIDs = new ArrayList<>();

// Current message details
private String messageID;
private String messageHash;
private String recipient;
private String message;

// Generate 10 digit message ID
public String generateMessageID() {

    Random rand = new Random();
    StringBuilder id = new StringBuilder();

    for (int i = 0; i < 10; i++) {
        id.append(rand.nextInt(10));
    }

    messageID = id.toString();
    return messageID;
}

// Check ID length
public boolean checkMessageID() {
    return messageID != null && messageID.length() == 10;
}

// Set recipient
public void setRecipient(String recipient) {
    this.recipient = recipient;
}

// Set message
public void setMessage(String message) {
    this.message = message;
}

// Get recipient
public String getRecipient() {
    return recipient;
}

// Get message
public String getMessage() {
    return message;
}

// Get message ID
public String getMessageID() {
    return messageID;
}

// Get message hash
public String getMessageHash() {
    return messageHash;
}

// Check message length
public String checkMessageLength() {

    if (message.length() <= 250) {
        return "Message ready to send.";
    }

    int extra = message.length() - 250;

    return "Message exceeds 250 characters by "
            + extra
            + " characters.";
}

// Create hash
public String createMessageHash() {

    String firstTwo = messageID.substring(0, 2);

    String[] words = message.split(" ");

    String firstWord = words[0].toUpperCase();

    String lastWord = words[words.length - 1]
            .replaceAll("[^a-zA-Z0-9]", "")
            .toUpperCase();

    messageHash =
            firstTwo + ":" +
            (messageHashes.size() + 1) + ":" +
            firstWord + lastWord;

    return messageHash;
}

// Message action
public String processMessage() {

    String[] options = {
        "Send Message",
        "Store Message",
        "Disregard Message"
    };

    int choice = JOptionPane.showOptionDialog(
            null,
            "Choose message option",
            "QuickChat",
            JOptionPane.DEFAULT_OPTION,
            JOptionPane.INFORMATION_MESSAGE,
            null,
            options,
            options[0]);

    if (choice == 0) {

        sentMessages.add(message);

        return "Message successfully sent";
    }

    if (choice == 1) {

        storedMessages.add(message);
        storedRecipients.add(recipient);

        messageIDs.add(messageID);
        messageHashes.add(messageHash);

        return "Message successfully stored";
    }

    disregardedMessages.add(message);

    return "Message disregarded";
}

}
