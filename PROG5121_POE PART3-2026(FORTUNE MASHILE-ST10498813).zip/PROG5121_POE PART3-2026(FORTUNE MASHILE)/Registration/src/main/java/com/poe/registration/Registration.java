/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.poe.registration;

/**
 *
 * @author fortune
 */
import javax.swing.JOptionPane;
public class Registration {


    // user details
    private String username;
    private String password;
    private String cellNumber;
    private String firstName;
    private String lastName;

    // MAIN METHOD - PROGRAM STARTS HERE
    public static void main(String[] args) {

        Registration reg = new Registration();
        reg.registerUser();

        // send data to login class
        Login login = new Login(
                reg.username,
                reg.password,
                reg.cellNumber,
                reg.firstName,
                reg.lastName
        );

        login.startLogin();
    }

    // register user details
    public void registerUser() {

        firstName = JOptionPane.showInputDialog("Enter first name:");
        lastName = JOptionPane.showInputDialog("Enter last name:");

        // username validation
        username = JOptionPane.showInputDialog("Enter username:");
        while (!checkUsername(username)) {
            username = JOptionPane.showInputDialog("Invalid username. Try again:");
        }

        // password validation
        password = JOptionPane.showInputDialog("Enter password:");
        while (!checkPassword(password)) {
            password = JOptionPane.showInputDialog("Invalid password. Try again:");
        }

        // cell validation
        cellNumber = JOptionPane.showInputDialog("Enter cell number:");
        while (!checkCellNumber(cellNumber)) {
            cellNumber = JOptionPane.showInputDialog("Invalid cell number. Try again:");
        }

        JOptionPane.showMessageDialog(null, "Registration successful!");
    }

    // username rule
    public static boolean checkUsername(String user) {
        return user.contains("_") && user.length() <= 5;
    }

    // password rule
    public static boolean checkPassword(String pass) {

        boolean cap = false;
        boolean num = false;
        boolean special = false;

        if (pass.length() < 8) return false;

        for (char c : pass.toCharArray()) {
            if (Character.isUpperCase(c)) cap = true;
            else if (Character.isDigit(c)) num = true;
            else if (!Character.isLetterOrDigit(c)) special = true;
        }

        return cap && num && special;
    }

    // SA number rule
    public static boolean checkCellNumber(String cell) {
        return cell.matches("\\+27\\d{9}");
    }
}
    
