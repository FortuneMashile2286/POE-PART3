/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.poe.registration;

/**
 *
 * @author fortune
 */
 import javax.swing.JOptionPane;
public class Login {

    // stored user info
    private String storedUsername;
    private String storedPassword;
    private String storedCell;
    private String firstName;
    private String lastName;

    // constructor
    public Login(String u, String p, String c, String f, String l) {
        storedUsername = u;
        storedPassword = p;
        storedCell = c;
        firstName = f;
        lastName = l;
    }

    // login method
    public void startLogin() {

        boolean loggedIn = false;

        while (!loggedIn) {

            String user = JOptionPane.showInputDialog("Enter username:");
            String pass = JOptionPane.showInputDialog("Enter password:");

            if (user.equals(storedUsername) && pass.equals(storedPassword)) {

                JOptionPane.showMessageDialog(null,
                        "Welcome " + firstName + " " + lastName);

                loggedIn = true;

                // go to main system
                QuickChat qc = new QuickChat();
                qc.startQuickChat(firstName, lastName);

            } else {
                JOptionPane.showMessageDialog(null, "Incorrect login details");
            }
        }
    }
}

