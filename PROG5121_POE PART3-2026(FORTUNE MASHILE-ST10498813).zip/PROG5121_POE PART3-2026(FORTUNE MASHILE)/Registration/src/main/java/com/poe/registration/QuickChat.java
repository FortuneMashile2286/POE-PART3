/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.poe.registration;

/**
 *
 * @author fortune
 */
 import javax.swing.JOptionPane;

public class QuickChat {

// Create message objects
Messages msg = new Messages();
MessageStoring store = new MessageStoring(msg);

// Called from Login.java
public void startQuickChat(String firstName, String lastName) {

    JOptionPane.showMessageDialog(
            null,
            "Welcome " + firstName + " " + lastName + " to QuickChat!"
    );

    // Ask user how many messages they want to process
    String input = JOptionPane.showInputDialog(
            "How many messages would you like to enter?"
    );

    if (input == null) {
        return;
    }

    int limit = Integer.parseInt(input);

    boolean running = true;

    while (running) {

        String[] menu = {
            "Send Message",
            "Show Sent Messages",
            "Stored Messages",
            "Quit"
        };

        int choice = JOptionPane.showOptionDialog(
                null,
                "QuickChat Main Menu",
                "QuickChat",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.INFORMATION_MESSAGE,
                null,
                menu,
                menu[0]
        );

        switch (choice) {

            case 0:

                if (limit <= 0) {

                    JOptionPane.showMessageDialog(
                            null,
                            "You have reached your message limit."
                    );

                    break;
                }

                sendMessage();
                limit--;
                break;

            case 1:

                displaySentMessages();
                break;

            case 2:

                storedMessagesMenu();
                break;

            default:

                running = false;
                break;
        }
    }

    JOptionPane.showMessageDialog(
            null,
            "Thank you for using QuickChat."
    );
}

// Send message
private void sendMessage() {

    msg.generateMessageID();

    String recipient =
            JOptionPane.showInputDialog(
                    "Enter recipient (+27...)");

    if (recipient == null) {
        return;
    }

    msg.setRecipient(recipient);

    String message =
            JOptionPane.showInputDialog(
                    "Enter message (max 250 characters)");

    if (message == null) {
        return;
    }

    msg.setMessage(message);

    String lengthCheck =
            msg.checkMessageLength();

    if (!lengthCheck.equals("Message ready to send.")) {

        JOptionPane.showMessageDialog(
                null,
                lengthCheck
        );

        return;
    }

    msg.createMessageHash();

    String result =
            msg.processMessage();

    JOptionPane.showMessageDialog(
            null,
            result
    );
}

// Display sent messages
private void displaySentMessages() {

    if (msg.sentMessages.isEmpty()) {

        JOptionPane.showMessageDialog(
                null,
                "No sent messages."
        );

        return;
    }

    String output = "";

    for (String message : msg.sentMessages) {

        output += message + "\n\n";
    }

    JOptionPane.showMessageDialog(
            null,
            output
    );
}

// Stored messages menu
private void storedMessagesMenu() {

    boolean back = false;

    while (!back) {

        String[] options = {
            "Display Sender & Recipient",
            "Display Longest Message",
            "Search Message ID",
            "Search Recipient",
            "Delete Message Hash",
            "Display Report",
            "Save JSON",
            "Load JSON",
            "Back"
        };

        int choice =
                JOptionPane.showOptionDialog(
                        null,
                        "Stored Messages Menu",
                        "Stored Messages",
                        JOptionPane.DEFAULT_OPTION,
                        JOptionPane.INFORMATION_MESSAGE,
                        null,
                        options,
                        options[0]
                );

        switch (choice) {

            case 0:

                store.displaySenderRecipient();
                break;

            case 1:

                store.longestMessage();
                break;

            case 2:

                String id =
                        JOptionPane.showInputDialog(
                                "Enter Message ID");

                if (id != null) {
                    store.searchID(id);
                }

                break;

            case 3:

                String recipient =
                        JOptionPane.showInputDialog(
                                "Enter Recipient");

                if (recipient != null) {
                    store.searchRecipient(recipient);
                }

                break;

            case 4:

                String hash =
                        JOptionPane.showInputDialog(
                                "Enter Message Hash");

                if (hash != null) {
                    store.deleteHash(hash);
                }

                break;

            case 5:

                store.report();
                break;

            case 6:

                store.saveJSON();
                break;

            case 7:

                store.loadJSON();
                break;

            default:

                back = true;
                break;
        }
    }
}


}
