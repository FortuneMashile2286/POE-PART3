/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.poe.registration;

/**
 *
 * @author fortune
 */
import javax.swing.JOptionPane;
import java.io.FileWriter;
import java.nio.file.Files;
import java.nio.file.Paths;

public class MessageStoring {

    // Link to Messages class
    private Messages msg;

    // Constructor
    public MessageStoring(Messages msg) {
        this.msg = msg;
    }

    // ==================================================
    // a) Display sender and recipient of stored messages
    // ==================================================
    public void displaySenderRecipient() {

        if (msg.storedMessages.isEmpty()) {

            JOptionPane.showMessageDialog(
                    null,
                    "No stored messages found."
            );

            return;
        }

        String output = "=== STORED MESSAGES ===\n\n";

        for (int i = 0; i < msg.storedMessages.size(); i++) {

            output += "Sender: User\n";
            output += "Recipient: "
                    + msg.storedRecipients.get(i)
                    + "\n\n";
        }

        JOptionPane.showMessageDialog(null, output);
    }

    // ===================================
    // b) Display longest stored message
    // ===================================
    public void longestMessage() {

        if (msg.storedMessages.isEmpty()) {

            JOptionPane.showMessageDialog(
                    null,
                    "No stored messages."
            );

            return;
        }

        String longest = "";

        for (String message : msg.storedMessages) {

            if (message.length() > longest.length()) {
                longest = message;
            }
        }

        JOptionPane.showMessageDialog(
                null,
                "Longest Message:\n\n" + longest
        );
    }

    // ===================================
    // c) Search by Message ID
    // ===================================
    public void searchID(String id) {

        int index = msg.messageIDs.indexOf(id);

        if (index != -1) {

            String output =
                    "Recipient: "
                    + msg.storedRecipients.get(index)
                    + "\n\nMessage:\n"
                    + msg.storedMessages.get(index);

            JOptionPane.showMessageDialog(
                    null,
                    output
            );
        }

        else {

            JOptionPane.showMessageDialog(
                    null,
                    "Message ID not found."
            );
        }
    }

    // ===================================
    // d) Search by Recipient
    // ===================================
    public void searchRecipient(String recipient) {

        String result = "";

        for (int i = 0; i < msg.storedRecipients.size(); i++) {

            if (msg.storedRecipients.get(i)
                    .equals(recipient)) {

                result +=
                        "Message ID: "
                        + msg.messageIDs.get(i)
                        + "\n";

                result +=
                        "Message: "
                        + msg.storedMessages.get(i)
                        + "\n\n";
            }
        }

        if (result.isEmpty()) {

            JOptionPane.showMessageDialog(
                    null,
                    "No messages found."
            );
        }

        else {

            JOptionPane.showMessageDialog(
                    null,
                    result
            );
        }
    }

    // ===================================
    // e) Delete by Message Hash
    // ===================================
    public void deleteHash(String hash) {

        int index = msg.messageHashes.indexOf(hash);

        if (index != -1) {

            String deletedMessage =
                    msg.storedMessages.get(index);

            msg.messageHashes.remove(index);
            msg.messageIDs.remove(index);
            msg.storedMessages.remove(index);
            msg.storedRecipients.remove(index);

            JOptionPane.showMessageDialog(
                    null,
                    "Message: \"" +
                    deletedMessage +
                    "\" successfully deleted."
            );
        }

        else {

            JOptionPane.showMessageDialog(
                    null,
                    "Message hash not found."
            );
        }
    }

    // ===================================
    // f) Display Report
    // ===================================
    public void report() {

        if (msg.storedMessages.isEmpty()) {

            JOptionPane.showMessageDialog(
                    null,
                    "No stored messages available."
            );

            return;
        }

        String report =
                "===== STORED MESSAGE REPORT =====\n\n";

        for (int i = 0; i < msg.storedMessages.size(); i++) {

            report +=
                    "Message Hash: "
                    + msg.messageHashes.get(i)
                    + "\n";

            report +=
                    "Recipient: "
                    + msg.storedRecipients.get(i)
                    + "\n";

            report +=
                    "Message: "
                    + msg.storedMessages.get(i)
                    + "\n\n";
        }

        JOptionPane.showMessageDialog(
                null,
                report
        );
    }

    // ===================================
    // Save Stored Messages to JSON
    // ===================================
    public void saveJSON() {

        try {

            FileWriter writer =
                    new FileWriter("messages.json");

            writer.write("[\n");

            for (int i = 0;
                 i < msg.storedMessages.size();
                 i++) {

                writer.write("  {\n");

                writer.write(
                        "    \"messageID\":\""
                        + msg.messageIDs.get(i)
                        + "\",\n");

                writer.write(
                        "    \"messageHash\":\""
                        + msg.messageHashes.get(i)
                        + "\",\n");

                writer.write(
                        "    \"recipient\":\""
                        + msg.storedRecipients.get(i)
                        + "\",\n");

                writer.write(
                        "    \"message\":\""
                        + msg.storedMessages.get(i)
                        + "\"\n");

                writer.write("  }");

                if (i <
                        msg.storedMessages.size() - 1) {

                    writer.write(",");
                }

                writer.write("\n");
            }

            writer.write("]");
            writer.close();

            JOptionPane.showMessageDialog(
                    null,
                    "messages.json saved successfully."
            );
        }

        catch (Exception e) {

            JOptionPane.showMessageDialog(
                    null,
                    "Error saving JSON file."
            );
        }
    }

    // ===================================
    // Load JSON File
    // ===================================
    public void loadJSON() {

        try {

            String data =
                    new String(
                            Files.readAllBytes(
                                    Paths.get("messages.json")
                            )
                    );

            JOptionPane.showMessageDialog(
                    null,
                    data
            );
        }

        catch (Exception e) {

            JOptionPane.showMessageDialog(
                    null,
                    "messages.json not found."
            );
        }
    }
}