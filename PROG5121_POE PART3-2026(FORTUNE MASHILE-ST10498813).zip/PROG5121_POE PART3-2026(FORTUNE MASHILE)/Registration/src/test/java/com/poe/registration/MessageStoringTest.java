/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.poe.registration;



/**
 *
 * @author fortune
 */
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MessageStoringTest {


@Test
public void testLongestMessage() {

    Messages msg = new Messages();

    msg.storedMessages.add("Did you get the cake?");
    msg.storedMessages.add("Where are you? You are late! I have asked you to be on time.");
    msg.storedMessages.add("Yohoooo, I am at your gate.");

    String longest = "";

    for(String m : msg.storedMessages) {

        if(m.length() > longest.length()) {
            longest = m;
        }
    }

    assertEquals(
            "Where are you? You are late! I have asked you to be on time.",
            longest
    );
}

@Test
public void testSearchMessageID() {

    Messages msg = new Messages();

    msg.messageIDs.add("MSG004");
    msg.storedRecipients.add("0838884567");
    msg.storedMessages.add("It is dinner time!");

    int index = msg.messageIDs.indexOf("MSG004");

    assertEquals(
            "It is dinner time!",
            msg.storedMessages.get(index)
    );
}

@Test
public void testSearchRecipient() {

    Messages msg = new Messages();

    msg.storedRecipients.add("+27838884567");
    msg.storedMessages.add(
            "Where are you? You are late! I have asked you to be on time."
    );

    msg.storedRecipients.add("+27838884567");
    msg.storedMessages.add(
            "Ok, I am leaving without you."
    );

    String result = "";

    for(int i = 0; i < msg.storedRecipients.size(); i++) {

        if(msg.storedRecipients.get(i)
                .equals("+27838884567")) {

            result += msg.storedMessages.get(i);
        }
    }

    assertTrue(
            result.contains(
                    "Where are you? You are late! I have asked you to be on time."
            )
    );

    assertTrue(
            result.contains(
                    "Ok, I am leaving without you."
            )
    );
}

@Test
public void testDeleteMessageHash() {

    Messages msg = new Messages();

    msg.messageHashes.add("hash002");
    msg.storedMessages.add(
            "Where are you? You are late! I have asked you to be on time."
    );

    int index = msg.messageHashes.indexOf("hash002");

    msg.messageHashes.remove(index);
    msg.storedMessages.remove(index);

    assertEquals(
            0,
            msg.storedMessages.size()
    );
}

@Test
public void testSentMessagesArray() {

    Messages msg = new Messages();

    msg.sentMessages.add("Did you get the cake?");
    msg.sentMessages.add("It is dinner time!");

    assertEquals(
            "Did you get the cake?",
            msg.sentMessages.get(0)
    );

    assertEquals(
            "It is dinner time!",
            msg.sentMessages.get(1)
    );
}


}
